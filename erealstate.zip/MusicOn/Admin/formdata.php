<?php 
    echo $email = $_REQUEST['email'];
    echo $password = $_REQUEST['pass'];
?>