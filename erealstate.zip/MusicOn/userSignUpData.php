<?php 
    echo $fName = $_REQUEST['fName'];
    echo $lNane = $_REQUEST['lName'];
    echo $pNumber = $_REQUEST['pNumber'];
    echo $email = $_REQUEST['email'];
    echo $password = $_REQUEST['pass'];
?>